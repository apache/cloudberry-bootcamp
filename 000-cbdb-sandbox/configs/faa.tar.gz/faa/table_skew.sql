SELECT  gp_segment_id, count(*) from faa.otp_c GROUP BY gp_segment_id ORDER BY gp_segment_id;

SELECT  gp_segment_id, count(*) from faa.otp_r GROUP BY gp_segment_id ORDER BY gp_segment_id;

